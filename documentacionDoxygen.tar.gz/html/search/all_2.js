var searchData=
[
  ['formatexception_4',['FormatException',['../classFormatException.html',1,'']]],
  ['fromnumber_5',['fromNumber',['../classBitString.html#a4b6949c90dc518f8cf9c120d16e721d8',1,'BitString']]]
];
