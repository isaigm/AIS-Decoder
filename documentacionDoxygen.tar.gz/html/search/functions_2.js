var searchData=
[
  ['getlastbits_81',['getLastBits',['../classPayload.html#a27e9e202505ae5beaa4f77f35f4486b2',1,'Payload']]],
  ['getnextnbits_82',['getNextNbits',['../classPayload.html#a8886c043d4330f23d0bc199ee22dd60c',1,'Payload']]]
];
