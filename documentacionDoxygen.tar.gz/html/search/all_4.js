var searchData=
[
  ['handlemultilinesentence_8',['handleMultilineSentence',['../classDecoder.html#aa32dbfb2a8942abbbdd7da623da097ee',1,'Decoder']]]
];
