var searchData=
[
  ['nmeamessageexception_34',['NMEAMessageException',['../classNMEAMessageException.html',1,'']]]
];
