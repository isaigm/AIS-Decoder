var searchData=
[
  ['nmeamessageexception_74',['NMEAMessageException',['../classNMEAMessageException.html',1,'']]]
];
